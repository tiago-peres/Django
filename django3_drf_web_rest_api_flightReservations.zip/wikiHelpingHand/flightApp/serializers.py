from rest_framework import serializers
from flightApp.models import Flight,Passenger,Reservation

class FlightSerializer(serializers.ModelSerializer):
    class Meta:
        model = Flight
        fields='__all__' # Ao usar __all__ significa que queremos usar todos os campos do modelo
                         # Se quisermos só alguns podemos usar fields=['flightNumber','operatingAirlines','departureCity']

class PassengerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Passenger
        fields='__all__'

class ReservationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reservation
        fields='__all__'
